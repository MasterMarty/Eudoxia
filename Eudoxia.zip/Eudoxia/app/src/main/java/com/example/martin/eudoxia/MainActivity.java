package com.example.martin.eudoxia;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(getSharedPreferences("Preferences",(MODE_PRIVATE)).getString("0", "Test")!="Valide"){
            Intent PremierLancement = new Intent(MainActivity.this, Preferences.class);
            startActivity(PremierLancement);
        }
    }
}
