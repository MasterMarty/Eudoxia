package com.example.martin.eudoxia;

/**
 * Created by Martin on 17/04/2017.
 */

public class Themes {

    public static final String[] sThemeStrings = {"Economie", "Cuisine", "Cinéma", "Politique", "Santé",
            "Jeux Vidéos", "Education", "Technologies"};
}
